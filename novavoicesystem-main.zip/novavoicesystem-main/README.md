# Nova Voice System
Deskripsi singkat:
Repository ini berisi tentang system voice Nova termasuk cara instalasinya. Mohon ikuti secara seksama terutama player PC/Laptop.

# Mohon Perhatian!
Sebelum memulai melakukan tahap ini, harap uninstall terlebih dahulu SA-MP yang ada di directory/folder GTA SA kalian (uninstall SA-MP kalian dulu) karena ini ada Client SA-MP rekomendasi dari Nova.

# Tutorial Pemasangan
Catatan: Ini khusus player PC/Laptop.
1. Download terlebih dahulu kedua file yang bernama "NovaClientVoice.zip" dan "NovaSAMPVersion.exe" (tanpa tanda petik).
2. Install terlebih dahulu file "NovaSAMPVersion.exe" dan pilih directory/folder dimana kamu menyimpan GTA San Andreas (tempat GTA SA kamu diinstall).
3. Buka file "NovaClientVoice.zip" dan pindahkan 5 file di dalamnya dengan cara extract ke directory/folder dimana kamu menyimpan GTA San Andreas (tempat GT SA kamu diinstall).
4. Jika pada saat extract muncul tulisan confirm tekan aja "Yes To All" yang ada di layar kalian ketika notifikasi tersebut muncul.
5. Jika sudah selesai, maka kalian sudah bisa roleplay di Nova.

# Have Fun~
- Nova Executive Team
